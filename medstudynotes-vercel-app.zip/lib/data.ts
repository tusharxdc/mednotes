export type Category = {
  name: string;
  slug: string;
  children?: Category[];
};

export const categories: Category[] = [
  { name: "MBBS", slug: "mbbs", children: [
    { name: "Anatomy", slug: "anatomy", children: [
      { name: "Neuroanatomy", slug: "neuroanatomy" },
      { name: "Upper Limb", slug: "upper-limb" }
    ]},
    { name: "Pharmacology", slug: "pharmacology", children: [
      { name: "Cardiovascular System", slug: "cardiovascular-system", children: [
        { name: "Antianginal Drugs", slug: "antianginal-drugs", children: [
          { name: "Nitrates", slug: "nitrates" }
        ]}
      ]},
      { name: "CNS Drugs", slug: "cns-drugs" }
    ]},
    { name: "Pathology", slug: "pathology", children: [
      { name: "Hematology", slug: "hematology", children: [
        { name: "Anemia", slug: "anemia" }
      ]}
    ]},
    { name: "Anesthesia", slug: "anesthesia", children: [
      { name: "General Anesthesia", slug: "general-anesthesia", children: [
        { name: "IV Induction Agents", slug: "iv-induction-agents" }
      ]}
    ]}
  ]},
  { name: "PG / Residency", slug: "pg-residency", children: [
    { name: "Medicine", slug: "medicine" },
    { name: "Surgery", slug: "surgery" },
    { name: "OBGYN", slug: "obgyn" }
  ]}
];

export const demoNotes = [
  {
    title: "Nitroglycerin Pharmacology Notes",
    slug: "nitroglycerin-pharmacology-notes",
    category: "Pharmacology / Cardiovascular / Antianginal Drugs",
    description: "Mechanism, uses, adverse effects, contraindications, and clinical pearls for nitroglycerin.",
    tags: ["Pharmacology", "CVS", "Nitrates", "Antianginal"],
    minutes: 4
  },
  {
    title: "Propofol Quick Revision",
    slug: "propofol-quick-revision",
    category: "Anesthesia / General Anesthesia / IV Induction Agents",
    description: "High-yield propofol notes with mechanism, dose points, adverse effects, and exam-focused facts.",
    tags: ["Anesthesia", "Propofol", "IV induction"],
    minutes: 3
  },
  {
    title: "Iron Deficiency Anemia",
    slug: "iron-deficiency-anemia",
    category: "Pathology / Hematology / Anemia",
    description: "Morphology, causes, lab findings, and clinical approach to iron deficiency anemia.",
    tags: ["Pathology", "Hematology", "Anemia"],
    minutes: 5
  }
];
