# Med Study Notes

A Next.js + Tailwind webapp for medstudynotes.online.

## Features
- Medical notes homepage
- Nested categories
- SEO metadata, sitemap and robots
- Note listing and note detail pages
- Browser OCR demo for uploaded note images using Tesseract.js
- Ready for Supabase storage/database and AI summary generation

## Deploy
Deploy to Vercel, then add the domain medstudynotes.online in Project Settings > Domains.
