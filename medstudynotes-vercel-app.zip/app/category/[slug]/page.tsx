import Link from "next/link";
import { demoNotes } from "@/lib/data";

export function generateMetadata({ params }: { params: { slug: string } }) {
  return { title: `${params.slug.replaceAll("-", " ")} Notes`, description: `Medical notes under ${params.slug.replaceAll("-", " ")}.` };
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const title = params.slug.replaceAll("-", " ");
  return (
    <main className="mx-auto max-w-6xl px-4 py-12">
      <Link href="/" className="font-bold text-medblue">← Home</Link>
      <h1 className="mt-6 capitalize text-5xl font-black text-ink">{title} notes</h1>
      <p className="mt-4 text-slate-600">Category landing page for SEO, topic discovery and related medical revision notes.</p>
      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {demoNotes.map(note => (
          <Link href={`/notes/${note.slug}`} key={note.slug} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-100 hover:shadow-soft">
            <p className="text-xs font-bold uppercase tracking-wider text-medteal">{note.category}</p>
            <h2 className="mt-2 text-2xl font-black text-medblue">{note.title}</h2>
            <p className="mt-3 text-slate-600">{note.description}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
