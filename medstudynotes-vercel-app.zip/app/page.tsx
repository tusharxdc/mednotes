import Image from "next/image";
import Link from "next/link";
import { BookOpen, Search, Layers3, ShieldCheck, Zap, Tags, ChevronRight } from "lucide-react";
import OcrUploader from "@/components/OcrUploader";
import { categories, demoNotes } from "@/lib/data";

function CategoryTree({ nodes, depth = 0 }: { nodes: any[]; depth?: number }) {
  return (
    <div className={depth ? "ml-4 border-l border-slate-200 pl-4" : ""}>
      {nodes.map(node => (
        <div key={node.slug} className="mb-3">
          <Link href={`/category/${node.slug}`} className="group flex items-center justify-between rounded-2xl bg-white px-4 py-3 font-bold text-ink shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-0.5 hover:text-medblue hover:shadow-md">
            <span>{node.name}</span>
            <ChevronRight className="h-4 w-4 text-slate-300 group-hover:text-medteal" />
          </Link>
          {node.children && <div className="mt-3"><CategoryTree nodes={node.children} depth={depth + 1} /></div>}
        </div>
      ))}
    </div>
  );
}

export default function Home() {
  return (
    <main>
      <header className="sticky top-0 z-30 border-b border-white/60 bg-white/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-3">
            <Image src="/logo.jpeg" alt="Med Study Notes logo" width={54} height={54} className="rounded-2xl" />
            <div>
              <p className="text-xl font-black leading-none text-medblue">medstudynotes</p>
              <p className="text-lg font-bold leading-none text-medteal">.online</p>
            </div>
          </Link>
          <nav className="hidden items-center gap-6 text-sm font-bold text-slate-600 md:flex">
            <a href="#notes" className="hover:text-medblue">Notes</a>
            <a href="#categories" className="hover:text-medblue">Categories</a>
            <a href="#upload" className="hover:text-medblue">Upload</a>
          </nav>
          <a href="#upload" className="rounded-full bg-medblue px-5 py-2.5 text-sm font-extrabold text-white shadow-lg shadow-blue-900/20 transition hover:bg-medteal">Upload note</a>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top_left,rgba(22,181,181,.22),transparent_32%),radial-gradient(circle_at_top_right,rgba(8,74,173,.18),transparent_30%)]" />
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 md:grid-cols-[1.1fr_.9fr] md:py-24">
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-bold text-medblue shadow-sm ring-1 ring-slate-100">
              <Zap className="h-4 w-4 text-medteal" /> OCR-powered medical notes library
            </div>
            <h1 className="text-5xl font-black tracking-tight text-ink md:text-7xl">
              Med Study Notes, organized for fast revision.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
              Upload handwritten notes, screenshots and diagrams. Extract OCR text, generate searchable descriptions, organize by deeply nested medical categories, and publish SEO-friendly study pages.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="#upload" className="rounded-full bg-medblue px-7 py-4 text-center font-extrabold text-white shadow-xl shadow-blue-900/20 transition hover:-translate-y-0.5 hover:bg-medteal">Start uploading</a>
              <a href="#categories" className="rounded-full bg-white px-7 py-4 text-center font-extrabold text-medblue ring-1 ring-slate-200 transition hover:-translate-y-0.5 hover:ring-medteal">Browse categories</a>
            </div>
            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {[
                ["SEO ready", "Sitemap, metadata, clean URLs"],
                ["Nested taxonomy", "Category > sub > sub-sub"],
                ["OCR workflow", "Extract, edit, publish"]
              ].map(([title, body]) => (
                <div key={title} className="rounded-3xl bg-white/80 p-4 shadow-sm ring-1 ring-slate-100">
                  <p className="font-black text-medblue">{title}</p>
                  <p className="mt-1 text-sm text-slate-500">{body}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-[2rem] bg-white p-8 shadow-soft ring-1 ring-slate-100">
            <Image src="/logo.jpeg" alt="Med Study Notes brand" width={720} height={720} className="rounded-[1.5rem]" priority />
            <div className="mt-6 rounded-3xl bg-slate-50 p-4">
              <div className="flex items-center gap-3 rounded-2xl bg-white px-4 py-3 ring-1 ring-slate-100">
                <Search className="text-medteal" />
                <span className="text-slate-400">Search pharmacology, anesthesia, diagrams...</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-8 md:grid-cols-4">
        {[
          [BookOpen, "Medical-first", "Built for MBBS, PG, residency and quick revision."],
          [Layers3, "Deep categories", "Supports category, subcategory and unlimited nesting."],
          [Tags, "Smart tags", "Autogenerated keywords from extracted note content."],
          [ShieldCheck, "Admin review", "Review OCR and AI fields before publishing."]
        ].map(([Icon, title, body]: any) => (
          <div key={title} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-100">
            <Icon className="mb-4 h-8 w-8 text-medteal" />
            <h3 className="text-lg font-black text-ink">{title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-500">{body}</p>
          </div>
        ))}
      </section>

      <section id="notes" className="mx-auto max-w-7xl px-4 py-12">
        <div className="mb-7 flex items-end justify-between gap-4">
          <div>
            <p className="font-extrabold uppercase tracking-widest text-medteal">Latest notes</p>
            <h2 className="text-4xl font-black text-ink">Recently published</h2>
          </div>
          <Link href="/notes" className="hidden rounded-full bg-white px-5 py-3 font-bold text-medblue ring-1 ring-slate-200 md:block">View all</Link>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {demoNotes.map(note => (
            <Link key={note.slug} href={`/notes/${note.slug}`} className="group rounded-[2rem] bg-white p-6 shadow-sm ring-1 ring-slate-100 transition hover:-translate-y-1 hover:shadow-soft">
              <div className="mb-5 flex h-36 items-center justify-center rounded-3xl bg-gradient-to-br from-medblue/10 to-medteal/10">
                <BookOpen className="h-14 w-14 text-medblue" />
              </div>
              <p className="text-xs font-bold uppercase tracking-wider text-medteal">{note.category}</p>
              <h3 className="mt-2 text-2xl font-black text-ink group-hover:text-medblue">{note.title}</h3>
              <p className="mt-3 leading-7 text-slate-600">{note.description}</p>
              <div className="mt-5 flex flex-wrap gap-2">
                {note.tags.map(tag => <span key={tag} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-500">{tag}</span>)}
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section id="categories" className="mx-auto grid max-w-7xl gap-8 px-4 py-12 lg:grid-cols-[.9fr_1.1fr]">
        <div>
          <p className="font-extrabold uppercase tracking-widest text-medteal">Category system</p>
          <h2 className="mt-2 text-4xl font-black text-ink">From subject to exact topic.</h2>
          <p className="mt-4 text-lg leading-8 text-slate-600">
            Use parent-child categories for medical subjects, systems, chapters, drug classes, diseases and microtopics.
          </p>
          <div className="mt-6 rounded-3xl bg-medblue p-6 text-white">
            <p className="font-black">Example</p>
            <p className="mt-2 text-blue-100">Pharmacology → Cardiovascular System → Antianginal Drugs → Nitrates → Nitroglycerin</p>
          </div>
        </div>
        <div className="rounded-[2rem] bg-slate-50 p-5 ring-1 ring-slate-100">
          <CategoryTree nodes={categories} />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-12">
        <OcrUploader />
      </section>

      <footer className="mt-16 border-t border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-8 text-sm text-slate-500 md:flex-row md:items-center md:justify-between">
          <p>© 2026 Med Study Notes. Built for medical education and revision.</p>
          <p className="font-semibold text-medblue">medstudynotes.online</p>
        </div>
      </footer>
    </main>
  );
}
