import type { MetadataRoute } from "next";
import { demoNotes } from "@/lib/data";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://medstudynotes.online";
  return [
    { url: base, lastModified: new Date() },
    { url: `${base}/notes`, lastModified: new Date() },
    ...demoNotes.map(note => ({ url: `${base}/notes/${note.slug}`, lastModified: new Date() }))
  ];
}
