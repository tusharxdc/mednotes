import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL("https://medstudynotes.online"),
  title: {
    default: "Med Study Notes | Medical Notes, Diagrams & Revision",
    template: "%s | Med Study Notes"
  },
  description: "Upload, organize, OCR and revise medical study notes with nested categories, searchable descriptions and SEO-friendly note pages.",
  keywords: ["medical notes", "MBBS notes", "pharmacology notes", "anesthesia notes", "OCR notes", "medical study"],
  openGraph: {
    title: "Med Study Notes",
    description: "Medical notes with OCR, categories and fast revision pages.",
    url: "https://medstudynotes.online",
    siteName: "Med Study Notes",
    images: ["/logo.jpeg"],
    type: "website"
  }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
