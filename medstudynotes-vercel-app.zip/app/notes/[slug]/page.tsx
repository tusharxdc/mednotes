import Link from "next/link";
import { notFound } from "next/navigation";
import { demoNotes } from "@/lib/data";

export function generateMetadata({ params }: { params: { slug: string } }) {
  const note = demoNotes.find(n => n.slug === params.slug);
  if (!note) return {};
  return {
    title: note.title,
    description: note.description,
    keywords: note.tags,
    openGraph: { title: note.title, description: note.description, images: ["/logo.jpeg"] }
  };
}

export default function NotePage({ params }: { params: { slug: string } }) {
  const note = demoNotes.find(n => n.slug === params.slug);
  if (!note) notFound();
  return (
    <main className="mx-auto max-w-4xl px-4 py-12">
      <Link href="/notes" className="font-bold text-medblue">← All notes</Link>
      <article className="mt-8 rounded-[2rem] bg-white p-6 shadow-soft ring-1 ring-slate-100 md:p-10">
        <p className="text-sm font-extrabold uppercase tracking-widest text-medteal">{note.category}</p>
        <h1 className="mt-3 text-5xl font-black text-ink">{note.title}</h1>
        <p className="mt-5 text-xl leading-9 text-slate-600">{note.description}</p>
        <div className="my-8 rounded-[2rem] bg-gradient-to-br from-medblue/10 to-medteal/10 p-10 text-center">
          <p className="text-lg font-black text-medblue">Uploaded note image preview</p>
          <p className="mt-2 text-slate-500">Production version will show the original uploaded note image here.</p>
        </div>
        <section className="prose-note rounded-3xl bg-slate-50 p-6">
          <h2 className="text-2xl font-black text-ink">Extracted OCR Text</h2>
          <p className="mt-4 text-slate-700">This demo page is ready for real OCR content from the admin uploader. Extracted text will be searchable and used to generate SEO metadata, summaries, related notes and tags.</p>
        </section>
        <div className="mt-7 flex flex-wrap gap-2">
          {note.tags.map(tag => <span key={tag} className="rounded-full bg-medteal/10 px-3 py-1 text-sm font-bold text-medblue">#{tag}</span>)}
        </div>
      </article>
    </main>
  );
}
