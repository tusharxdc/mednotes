import Link from "next/link";
import { demoNotes } from "@/lib/data";

export const metadata = { title: "All Notes", description: "Browse all medical study notes on Med Study Notes." };

export default function NotesPage() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-12">
      <Link href="/" className="font-bold text-medblue">← Home</Link>
      <h1 className="mt-6 text-5xl font-black text-ink">All medical notes</h1>
      <p className="mt-4 text-slate-600">Searchable SEO-ready medical notes organized by subject and topic.</p>
      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {demoNotes.map(note => (
          <Link href={`/notes/${note.slug}`} key={note.slug} className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-100 hover:shadow-soft">
            <p className="text-xs font-bold uppercase tracking-wider text-medteal">{note.category}</p>
            <h2 className="mt-2 text-2xl font-black text-medblue">{note.title}</h2>
            <p className="mt-3 text-slate-600">{note.description}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
