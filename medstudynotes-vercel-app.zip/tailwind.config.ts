import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        medblue: "#084aad",
        medteal: "#16b5b5",
        ink: "#122033"
      },
      boxShadow: {
        soft: "0 18px 60px rgba(8,74,173,.14)"
      }
    }
  },
  plugins: []
};
export default config;
